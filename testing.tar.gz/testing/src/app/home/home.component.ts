import { Component, OnInit } from '@angular/core';
import { GetDataService } from '../get-data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  data: any;
  allData: any;
  dataLoaded: boolean = false;
  displayData: any;
  constructor(private getDataService: GetDataService) { }

  loadData(x) {
    console.log(this.allData);
    for (let i=0; i < this.allData.length ; i++){
      if (this.allData[i].company == x){
        this.displayData = this.allData[i];
        console.log(this.displayData);
      }
    }
  }

  ngOnInit() {
    this.getDataService
      .getDetails()
      .subscribe(val => {
        this.data = val;
        console.log(this.data);
        this.dataLoaded = true;
      })

this.getDataService
      .getAllDetails()
      .subscribe(val => {
        this.allData = val;
      })
  }

}
