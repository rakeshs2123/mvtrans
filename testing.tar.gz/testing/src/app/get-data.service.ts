import { Injectable }     from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';

// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class GetDataService {

  constructor(private http: Http) { }

getAllDetails(){
  return this.http.get('assets/data.json')
                .map((res:Response) => res.json())
}

getDetails(){
  return this.http.get('assets/singleData.json')
                .map((res:Response) => res.json())
}

}
